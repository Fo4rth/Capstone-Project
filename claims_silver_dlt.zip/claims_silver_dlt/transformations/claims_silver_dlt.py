import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


@dlt.table(comment="Raw batch claims data from bronze layer")
def claims_batch_bronze():
    return spark.read.table("capstone.bronze.claims_batch")


@dlt.table(
    comment="Cleansed, validated, and unified claims table (Silver)",
    table_properties={
        "quality": "silver",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true"
    }
)
@dlt.expect_or_drop("valid_claim_id", "ClaimID IS NOT NULL")
@dlt.expect_or_drop("valid_member_id", "MemberID IS NOT NULL")
@dlt.expect_or_drop("valid_provider_id", "ProviderID IS NOT NULL")
@dlt.expect_or_drop("valid_amount", "Amount > 0")
@dlt.expect_or_drop("valid_claim_date", "ClaimDate IS NOT NULL")
@dlt.expect_or_drop("valid_service_date", "ServiceDate IS NOT NULL")
def silver_claims():
    batch_claims = dlt.read("claims_batch_bronze")
    
    # Deduplicate based on ClaimID (keep latest ingestion)
    windowSpec = Window.partitionBy("ClaimID").orderBy(col("IngestionTimestamp").desc())
    deduped_claims = (batch_claims
        .withColumn("rn", row_number().over(windowSpec))
        .filter(col("rn") == 1)
        .drop("rn")
    )
    
    icd_processed = (deduped_claims
        .withColumn("PrimaryICD10", split(col("ICD10Codes"), "[,;]")[0])
        .withColumn("ICD10CodeCount", size(split(col("ICD10Codes"), "[,;]")))
    )
    
    final_claims = (icd_processed
        .withColumn("ClaimAgeInDays", 
                   datediff(col("IngestionTimestamp"), col("ClaimDate")))
        .withColumn("ServiceToClaimDays", 
                   datediff(col("ClaimDate"), col("ServiceDate")))
        .withColumn("AmountCategory", 
                   when(col("Amount") < 100, "Low")
                   .when(col("Amount") < 1000, "Medium")
                   .when(col("Amount") < 10000, "High")
                   .otherwise("Very High"))
        .withColumn("IsHighValue", col("Amount") > 5000)
        .withColumn("ProcessedTimestamp", current_timestamp())
    )
    
    return final_claims