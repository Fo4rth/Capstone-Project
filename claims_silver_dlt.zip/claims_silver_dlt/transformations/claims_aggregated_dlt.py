import dlt
from pyspark.sql.functions import *


@dlt.table(
    comment="Aggregated claims metrics by provider and status"
)
def provider_claims_summary():
    return (
        dlt.read("silver_claims")
        .groupBy("ProviderID", "Status")
        .agg(
            count("ClaimID").alias("total_claims"),
            sum("Amount").alias("total_amount"),
            avg("Amount").alias("avg_amount"),
            min("Amount").alias("min_amount"),
            max("Amount").alias("max_amount"),
            countDistinct("MemberID").alias("unique_members"),
            sum(when(col("IsHighValue"), 1).otherwise(0)).alias("high_value_claims")
        )
        .withColumn("avg_amount_per_member", col("total_amount") / col("unique_members"))
        .withColumn("high_value_percentage", 
                   round((col("high_value_claims") / col("total_claims")) * 100, 2))
    )


@dlt.table(
    comment="Monthly claims trends and patterns"
)
def monthly_claims_trends():
    return (
        dlt.read("silver_claims")
        .withColumn("claim_year_month", date_format(col("ClaimDate"), "yyyy-MM"))
        .groupBy("claim_year_month", "ClaimType", "Status")
        .agg(
            count("ClaimID").alias("monthly_claims"),
            sum("Amount").alias("monthly_amount"),
            avg("Amount").alias("avg_claim_amount"),
            countDistinct("MemberID").alias("unique_members"),
            countDistinct("ProviderID").alias("unique_providers")
        )
        .orderBy("claim_year_month", "ClaimType")
    )