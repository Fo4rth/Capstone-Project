# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE capstone.gold.claims_enhanced
# MAGIC AS
# MAGIC SELECT
# MAGIC c.ClaimID,
# MAGIC c.ClaimDate,
# MAGIC c.ServiceDate,
# MAGIC c.Amount AS ClaimAmount,
# MAGIC c.StandardizedStatus AS ClaimStatus,
# MAGIC c.ClaimType,
# MAGIC c.SubmissionChannel,
# MAGIC c.PrimaryICD10 AS PrimaryDiagnosisCode,
# MAGIC c.DiagnosisDescription,
# MAGIC c.ICD10Codes AS AllDiagnosisCodes,
# MAGIC c.CPTCodes,
# MAGIC c.FraudRiskScore,
# MAGIC c.DataQualityFlags,
# MAGIC c.DaysToSubmit,
# MAGIC c.ClaimCategory,
# MAGIC c.SubmissionTimeliness,
# MAGIC c.ClaimComplexity,
# MAGIC c.IsWeekendService,
# MAGIC c.LikelyEmergency,
# MAGIC m.MemberID,
# MAGIC CONCAT(m.FirstName, ' ', m.LastName) AS MemberName,
# MAGIC m.Age AS MemberAge,
# MAGIC m.AgeGroup,
# MAGIC m.Gender AS MemberGender,
# MAGIC m.Plan AS MemberPlan,
# MAGIC m.IsActiveMember,
# MAGIC m.TenureDays AS MemberTenureDays,
# MAGIC p.ProviderID,
# MAGIC p.ProviderName,
# MAGIC p.Specialty AS ProviderSpecialty,
# MAGIC p.City AS ProviderCity,
# MAGIC p.State AS ProviderState,
# MAGIC p.ZipCode AS ProviderZipCode,
# MAGIC p.SpecialtyCount AS ProviderSpecialtyCount,
# MAGIC YEAR(c.ClaimDate) AS ClaimYear,
# MAGIC MONTH(c.ClaimDate) AS ClaimMonth,
# MAGIC QUARTER(c.ClaimDate) AS ClaimQuarter,
# MAGIC DAYOFWEEK(c.ServiceDate) AS ServiceDayOfWeek,
# MAGIC CASE
# MAGIC WHEN DAYOFWEEK(c.ServiceDate) IN (1, 7) THEN 'Weekend'
# MAGIC ELSE 'Weekday'
# MAGIC END AS ServiceDayType
# MAGIC FROM capstone.silver.claims c
# MAGIC INNER JOIN capstone.silver.members m ON c.MemberID = m.MemberID
# MAGIC INNER JOIN capstone.silver.providers p ON c.ProviderID = p.ProviderID
# MAGIC WHERE c.DataQualityFlags = 'CLEAN';

# COMMAND ----------

