# Databricks notebook source
# %sql
# -- CREATE THE CAPSTONE CATALOG (if it doesn't exist)
# CREATE CATALOG IF NOT EXISTS capstone;
# USE CATALOG capstone;

# -- Create schemas for our medallion layers
# CREATE SCHEMA IF NOT EXISTS bronze;
# CREATE SCHEMA IF NOT EXISTS silver;
# CREATE SCHEMA IF NOT EXISTS gold;

# -- Create Volumes for storing raw files
# CREATE VOLUME IF NOT EXISTS bronze.raw_files;
# CREATE VOLUME IF NOT EXISTS bronze.checkpoints;

# -- -- List the volumes to confirm and get their paths
# -- LIST VOLUMES IN bronze;
# -- -- Note the path: e.g., '/Volumes/capstone/bronze/raw_files/'

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, input_file_name

raw_files_path = '/Volumes/capstone/bronze/raw_files'

spark.sql("""
CREATE OR REPLACE TABLE capstone.bronze.claims_batch (
ClaimID STRING,
MemberID STRING,
ProviderID STRING,
ClaimDate DATE,
ServiceDate DATE,
Amount DOUBLE,
Status STRING,
ICD10Codes STRING,
CPTCodes STRING,
ClaimType STRING,
SubmissionChannel STRING,
Notes STRING,
IngestTimestamp TIMESTAMP,
IngestionTimestamp TIMESTAMP
)
USING DELTA
""")

spark.sql(f"""
COPY INTO capstone.bronze.claims_batch
FROM (
SELECT
ClaimID,
MemberID,
ProviderID,
TO_DATE(ClaimDate) AS ClaimDate,
TO_DATE(ServiceDate) AS ServiceDate,
CAST(Amount AS DOUBLE) AS Amount,
Status,
ICD10Codes,
CPTCodes,
ClaimType,
SubmissionChannel,
Notes,
CAST(IngestTimestamp AS TIMESTAMP) AS IngestTimestamp,
current_timestamp() AS IngestionTimestamp
FROM '{raw_files_path}/claims_batch.csv'
)
FILEFORMAT = CSV
FORMAT_OPTIONS ('header' = 'true', 'inferSchema' = 'true')
COPY_OPTIONS ('mergeSchema' = 'true')
""")

print('Loaded capstone.bronze.claims_batch')

print('Tables in capstone.bronze:')
spark.sql("SHOW TABLES IN capstone.bronze").show()

print('\nClaims batch schema:')
spark.sql("DESCRIBE capstone.bronze.claims_batch").show()

print('\nSample claims data:')
spark.sql("SELECT * FROM capstone.bronze.claims_batch LIMIT 5").show(truncate=False)

print('\nTotal records loaded:')
spark.sql("SELECT COUNT(*) as record_count FROM capstone.bronze.claims_batch").show()

print('\nData quality check - NULL values:')
spark.sql("""
SELECT 
  SUM(CASE WHEN ClaimID IS NULL THEN 1 ELSE 0 END) as null_claim_id,
  SUM(CASE WHEN MemberID IS NULL THEN 1 ELSE 0 END) as null_member_id,
  SUM(CASE WHEN Amount IS NULL THEN 1 ELSE 0 END) as null_amount,
  SUM(CASE WHEN ClaimDate IS NULL THEN 1 ELSE 0 END) as null_claim_date
FROM capstone.bronze.claims_batch
""").show()