import dlt
from pyspark.sql.functions import *


@dlt.table(
    comment="Enhanced claims data with member and provider information (Gold layer)",
    table_properties={
        "quality": "gold",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true"
    }
)
def claims_enhanced():
    claims = dlt.read("silver_claims")
    members = spark.read.table("capstone.silver.members")
    providers = spark.read.table("capstone.silver.providers")
    
    enhanced_claims = (claims
        .join(members, "MemberID", "inner")
        .join(providers, "ProviderID", "inner")
        .select(
            col("ClaimID"),
            col("ClaimDate"),
            col("ServiceDate"),
            col("Amount").alias("ClaimAmount"),
            col("Status").alias("ClaimStatus"), 
            col("ClaimType"),
            col("SubmissionChannel"),
            col("PrimaryICD10").alias("PrimaryDiagnosisCode"),
            col("ICD10Codes").alias("AllDiagnosisCodes"),
            col("CPTCodes"),
            col("AmountCategory").alias("ClaimCategory"),
            col("ClaimAgeInDays").alias("DaysToSubmit"),
            col("ServiceToClaimDays"),
            col("IsHighValue"),
            
            col("MemberID"),
            concat(col("FirstName"), lit(" "), col("LastName")).alias("MemberName"),
            col("Age").alias("MemberAge"),
            col("Gender").alias("MemberGender"),
            col("Plan").alias("MemberPlan"),

            col("ProviderID"),
            col("ProviderName"),
            col("Specialty").alias("ProviderSpecialty"),
            col("City").alias("ProviderCity"),
            col("State").alias("ProviderState"),
            col("ZipCode").alias("ProviderZipCode"),
            
            year(col("ClaimDate")).alias("ClaimYear"),
            month(col("ClaimDate")).alias("ClaimMonth"),
            quarter(col("ClaimDate")).alias("ClaimQuarter"),
            dayofweek(col("ServiceDate")).alias("ServiceDayOfWeek"),
            
            # Derived fields
            when(dayofweek(col("ServiceDate")).isin(1, 7), "Weekend")
            .otherwise("Weekday").alias("ServiceDayType"),
            
            # Processing timestamp
            col("ProcessedTimestamp")
        )
    )
    
    return enhanced_claims


@dlt.table(
    comment="Claims analytics summary for business intelligence (Gold layer)"
)
def claims_analytics_summary():
    return (
        dlt.read("claims_enhanced")
        .groupBy(
            "ClaimYear", 
            "ClaimMonth", 
            "ProviderSpecialty", 
            "MemberPlan",
            "ClaimStatus"
        )
        .agg(
            count("ClaimID").alias("total_claims"),
            sum("ClaimAmount").alias("total_amount"),
            avg("ClaimAmount").alias("avg_claim_amount"),
            countDistinct("MemberID").alias("unique_members"),
            countDistinct("ProviderID").alias("unique_providers"),
            sum(when(col("ServiceDayType") == "Weekend", 1).otherwise(0)).alias("weekend_claims"),
            sum(when(col("IsHighValue"), 1).otherwise(0)).alias("high_value_claims"),
            avg("DaysToSubmit").alias("avg_days_to_submit")
        )
        .withColumn("weekend_claim_percentage", 
                   round((col("weekend_claims") / col("total_claims")) * 100, 2))
        .withColumn("high_value_percentage",
                   round((col("high_value_claims") / col("total_claims")) * 100, 2))
        .withColumn("avg_amount_per_member",
                   round(col("total_amount") / col("unique_members"), 2))
    )